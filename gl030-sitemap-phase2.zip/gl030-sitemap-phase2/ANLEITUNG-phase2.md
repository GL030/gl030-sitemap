# Phase 2: Automatische Event-Sitemap + IndexNow (Stand 20.07.2026)

**Was danach automatisch läuft, jeden Morgen 06:30, für immer:**
Generator liest die Tages-Seiten (heute + 14 Tage, DE + EN) → baut `sitemap-events.xml` (aktuell 739 Event-URLs) → pusht sie ins Repo (GitHub Pages liefert sie aus, das Cloudflare-Snippet stellt sie unter eurer Domain bereit) → **neue Event-URLs werden sofort per IndexNow an Bing gemeldet**. Kein manuelles Einreichen mehr, keine Abhängigkeit vom Server, kein Wartungsaufwand.

---

## Schritt 1: Dateien ins GitHub-Repo (5 Min)

Repo `gl030/gl030-sitemap` öffnen → **Add file → Upload files** → den **Inhalt** des Ordners `phase2/` hineinziehen (Ordnerstruktur `.github/workflows/` muss erhalten bleiben – am einfachsten: alle Dateien UND den .github-Ordner gemeinsam per Drag & Drop) → Commit.

Enthalten:
- `generate_events_sitemap.py` – der Generator
- `sitemap-events.xml` – erster Stand (heute von mir erzeugt, 739 URLs)
- `4a9d18ffb7c08074334bcfee479f8c4a.txt` – IndexNow-Schlüsseldatei
- `.github/workflows/events-sitemap.yml` – der Zeitplan (täglich 06:30)
- `sitemap-berlin.xml` – nur falls noch nicht im Repo (sonst überspringen)

## Schritt 2: GitHub-Secret anlegen (2 Min)

Repo → **Settings → Secrets and variables → Actions → New repository secret**
- Name: `INDEXNOW_KEY`
- Wert: `4a9d18ffb7c08074334bcfee479f8c4a`

(Das zweite im Workflow erwähnte Secret `GL030_BYPASS_TOKEN` ist NICHT nötig – der Test lief ohne Blockierung durch. Es ist nur die vorbereitete Notfalltür, falls der Bot-Schutz die Action je aussperrt.)

## Schritt 3: Cloudflare-Snippet aktualisieren (3 Min)

1. Regeln → Snippets → `sitemapproxy` → **Bearbeiten**
2. Kompletten Code durch den Inhalt von `snippet-sitemap-proxy-v2.js` ersetzen → Speichern
3. **Snippet-Regel bearbeiten** – Expression ersetzen durch:
```
(http.host eq "www.gaesteliste030.de" and (http.request.uri.path eq "/content/sitemap/sitemap-berlin.xml" or http.request.uri.path eq "/sitemap.xml" or http.request.uri.path eq "/content/sitemap/sitemap-events.xml" or http.request.uri.path eq "/4a9d18ffb7c08074334bcfee479f8c4a.txt"))
```
4. Bereitstellen

## Schritt 4: Erster Testlauf (2 Min)

Repo → Tab **Actions** → „Event-Sitemap taeglich aktualisieren" → **Run workflow**. 
Grüner Haken nach ~2 Minuten = alles verkabelt. Im Log steht die Zahl der gefundenen Events und der IndexNow-Status (beim ersten Lauf: „Keine neuen URLs", weil der heutige Stand schon committed ist – normal).

## Schritt 5: Event-Sitemap einreichen (je 1 Min, einmalig)

- **GSC** → Sitemaps → `content/sitemap/sitemap-events.xml` → Senden
- **Bing** → Sitemaps → Submit → `https://www.gaesteliste030.de/content/sitemap/sitemap-events.xml`

---

## Danach: Verifikation durch Claude

Bescheid geben, sobald Schritte 1–4 durch sind – ich prüfe von außen: Event-Sitemap unter der Domain erreichbar, Key-Datei erreichbar (Voraussetzung, dass IndexNow die Pings akzeptiert), XML valide.

## Betrieb & Grenzen (ehrlich)

- **Selbstschutz:** Findet der Generator 0 Events (Blockierung, Strukturänderung), bricht er ab, statt die Sitemap zu leeren – die letzte gute Version bleibt live.
- **Abhängigkeit:** Der Generator hängt an der HTML-Struktur der Tages-Seiten (`href`-Muster der Event-Links). Ändert sich das Template, muss die eine Regex angepasst werden – 5-Minuten-Fix, und der Fehllauf fällt durch rote Action-Läufe sofort auf (GitHub mailt bei Fehlschlägen an die Repo-Adresse).
- **Ablösung:** Wenn die serverseitige Sitemap-Generierung (Claude-Code-Ticket, Phase 3) live geht, werden Workflow + Snippet einfach gelöscht. Die eingereichten Sitemap-URLs bleiben identisch – GSC und Bing merken vom Unterbau-Wechsel nichts.
- **ES fehlt bewusst:** Spanische Event-Seiten leiten um und existieren nicht als eigene URLs.
