// GL030 Sitemap-Proxy v2 (ersetzt v1)
// Liefert Kern-Sitemap, Event-Sitemap und IndexNow-Key-Datei
// aus dem GitHub-Pages-Hosting unter der eigenen Domain aus.

const REPO = "https://gl030.github.io/gl030-sitemap";

const ROUTES = {
  "/content/sitemap/sitemap-berlin.xml": { file: "/sitemap-berlin.xml", type: "application/xml; charset=utf-8" },
  "/sitemap.xml":                        { file: "/sitemap-berlin.xml", type: "application/xml; charset=utf-8" },
  "/content/sitemap/sitemap-events.xml": { file: "/sitemap-events.xml", type: "application/xml; charset=utf-8" },
  "/4a9d18ffb7c08074334bcfee479f8c4a.txt": { file: "/4a9d18ffb7c08074334bcfee479f8c4a.txt", type: "text/plain; charset=utf-8" },
};

export default {
  async fetch(request) {
    const path = new URL(request.url).pathname;
    const route = ROUTES[path];
    if (!route) return fetch(request);

    const upstreamResponse = await fetch(REPO + route.file, {
      cf: { cacheTtl: 1800, cacheEverything: true },
    });
    if (!upstreamResponse.ok) {
      return fetch(request);
    }
    return new Response(upstreamResponse.body, {
      status: 200,
      headers: {
        "content-type": route.type,
        "cache-control": "public, max-age=1800",
        "x-sitemap-source": "proxy-v2",
      },
    });
  },
};
